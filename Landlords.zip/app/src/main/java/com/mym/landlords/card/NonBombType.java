package com.mym.landlords.card;

/**标记接口， 表示非炸弹类型。 */
public interface NonBombType {

}
