package com.mym.landlords.card;

/**标记接口， 表示炸弹类型。 */
public interface BombType {

}
