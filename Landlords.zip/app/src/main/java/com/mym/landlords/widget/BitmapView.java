package com.mym.landlords.widget;

import android.graphics.Canvas;
public interface BitmapView {
	/** 绘制组件。  */
	void onPaint(Canvas canvas);
}
